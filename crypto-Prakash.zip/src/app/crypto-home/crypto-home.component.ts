import { Component,OnInit} from '@angular/core';
import { CryptoApiService } from '../service/crypto-api.service';
import * as Highcharts from 'highcharts';
import { MatTableDataSource } from '@angular/material/table';
@Component({
  selector: 'app-crypto-home',
  templateUrl: './crypto-home.component.html',
  styleUrls: ['./crypto-home.component.scss']
})
export class CryptoHomeComponent implements OnInit {

  constructor(){}


  ngOnInit(): void {
    // throw new Error('Method not implemented.');
  }

}
