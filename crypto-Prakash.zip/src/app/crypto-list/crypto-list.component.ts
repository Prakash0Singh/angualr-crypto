import { Component,OnInit } from '@angular/core';
import { CryptoApiService } from '../service/crypto-api.service';
import * as Highcharts from 'highcharts';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { LoaderComponent } from '../loader/loader.component';
import { OwlOptions } from 'ngx-owl-carousel-o';
@Component({
  selector: 'app-crypto-list',
  templateUrl: './crypto-list.component.html',
  styleUrls: ['./crypto-list.component.scss']
})
export class CryptoListComponent implements OnInit {

  length = 100;
  pageSize = 10;
  pageIndex=1;
  pageSizeOptions: number[] = [5, 10, 25, 30];


  coins_data: any=[];
  test='bitcon'
  unit: boolean=false;
  dataSource:any
  page_number=1;
  trending_coins: any=[];
  search_result:any=[]
  currency_supported: any=[];
  global_data :any={};

  constructor(private _cryptoApi:CryptoApiService,public router:Router,private dialog:MatDialog){}

  displayedColumns: string[] = ['rank', 'name','currprice','hour','day','week','marketcap','chart'];

  customOptions: OwlOptions = {
    loop: true,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: true,
    dots: false,
    autoplay:true,
    navSpeed: 400,
    navText: ["<i class='text-light bi bi-chevron-left'></i>", "<i class='text-light bi bi-chevron-right'></i>"],
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 2
      },
      740: {
        items: 4
      },
      940: {
        items: 4
      }
    },
    nav: true
  }
  currency="INR"


  ngOnInit(): void {
    let default_page = JSON.parse(localStorage.getItem("page") || '[10,1]')
    this.pageSize=default_page[0]
    this.pageIndex=default_page[1]-1
    this.dialog.open(LoaderComponent)
    this.global_market()
    this.support_curr()
    this.trending()
    this.call_api(default_page[0],default_page[1]);

  }

  support_curr(){
    this._cryptoApi.currency_supported().subscribe({
      next:(res)=>{
        this.currency_supported=res
      }
    })
  }

  global_market(){
    this._cryptoApi.global_crypto().subscribe({
      next:(res:any)=>{
        console.log(res.data);
        this.global_data=res.data
      },
      error:(err)=>{

      },
      complete:()=>{

      }
    })
  }

  trending(){
    this._cryptoApi.trending_coin().subscribe({
      next:(res:any)=>{
        this.trending_coins=res.coins
      },
      error:(err)=>{

      },complete:()=>{

      }
    })
  }

  call_api(a:number,b:number) {

    this._cryptoApi.crypto_list(a,b,this.currency).subscribe({
      next: (res: any) => {
        this.coins_data=res 
        this.dataSource = new MatTableDataSource(this.coins_data);;

        res.forEach((d: any) => {
          setTimeout(() => {
            this.crypto_chart(d.id, d.sparkline_in_7d.price, d.price_change_percentage_7d_in_currency);
          }, 10);
        });
      },
      error: (err) => {
        // console.log(err);
        localStorage.clear();
        this.dialog.closeAll();
        this._cryptoApi.snackMessage('Api limit has reached !!!')
        // this.router.navigate([''])
      },
      complete: () => {
        this.dialog.closeAll(); 
      }
    });
  }

  crypto_chart(id:string,data:any,week_rec:number){
    const chart = Highcharts.chart(id, {
      chart: {
        height: '50px',
      },
      credits: {
        enabled: false
      },
      title: {
          text: null,
      },
      xAxis: {
        visible:false,
      },
      yAxis: {
        visible:false
      },
      legend: {
          enabled: false
      },
      plotOptions: {
          area: {
              fillColor: {
                color:'transparent'
              },
              marker: {
                enabled: false,
                symbol: 'circle',
                radius: 1,
                states: {
                    hover: {
                        enabled: false
                    }
                }
            },
              lineWidth: 1,
              states: {
                  hover: {
                      lineWidth: 0,
                      enabled:false
                  }
              },
              threshold: null
          }
      },

      series: [{
        color:week_rec>1?'#16c784':'#ea3943',
          type: 'area',
          data: data,
          enableMouseTracking: false,
      }]
  
  } as any);
  }

  change_degree(event:any){
    console.log(event.target.checked);
    localStorage.setItem('tempUnit',event.target.checked)

    this.unit=JSON.parse(localStorage.getItem('tempUnit')||'false')
  }

  pageEvent(event:any){
    console.log(event);
    let data=[event.pageSize,event.pageIndex+1]
    localStorage.setItem('page',JSON.stringify(data))
    this.call_api(event.pageSize,event.pageIndex+1)
  }

  search_word(event:any){
    console.log(event);

    if (event.length>=4) {

      this._cryptoApi.search_coin(event).subscribe({
        next:(res:any)=>{
          console.log(res);
          this.search_result=res.coins
        },error:(err)=>{
  
        },complete:()=>{
  
        }
      })

    } else {
      this._cryptoApi.snackMessage('Minimum 4 Character is Required')
    }
   
  }

  change_currency(curr:string){
    this.currency=curr;
    let default_page = JSON.parse(localStorage.getItem("page") || '[10,1]')
    this.call_api(default_page[0],default_page[1]);
  }

}
