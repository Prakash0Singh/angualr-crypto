import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CryptoHomeComponent } from './crypto-home/crypto-home.component';
import { CryptoListComponent } from './crypto-list/crypto-list.component';
import { CryptoChartComponent } from './crypto-chart/crypto-chart.component';
import { CryptoInfoComponent } from './crypto-info/crypto-info.component';

const routes: Routes = [
  {path:'',component:CryptoHomeComponent},
  {path:'crypto',component:CryptoListComponent},
  {path:'crypto-chart/:id',component:CryptoChartComponent},
  {path:'crypto-info/:id',component:CryptoInfoComponent},
  {path:'**',component:CryptoHomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
