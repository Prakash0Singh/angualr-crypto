import { Component,OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { CryptoApiService } from '../service/crypto-api.service';
import { LoaderComponent } from '../loader/loader.component';

@Component({
  selector: 'app-crypto-info',
  templateUrl: './crypto-info.component.html',
  styleUrls: ['./crypto-info.component.scss']
})
export class CryptoInfoComponent implements OnInit {
  crypto_id: any;
  coin_data: any={};
  coin_description=''

  constructor(private activeRouter:ActivatedRoute,public router:Router,private _cryptoApi:CryptoApiService,private dialog:MatDialog){}

  ngOnInit(){
    this.dialog.open(LoaderComponent)
    this.crypto_id= this.activeRouter.snapshot.paramMap.get('id') 
    this.coin_details() 
  }

  coin_details(){
    this._cryptoApi.coin_info(this.crypto_id).subscribe({
      next:(res:any)=>{
        console.log(res);
        this.coin_data=res
        this.coin_description=res.description.en

      },
      error:(err)=>{
        console.log(err);
      },
      complete:()=>{
        this.dialog.closeAll()
      }
    })
  }
}
