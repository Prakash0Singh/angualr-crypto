import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class CryptoApiService {

  constructor(private http:HttpClient,private router:Router,private _snackBar: MatSnackBar) { }

  coin_info(id:string){
    return this.http.get(`https://api.coingecko.com/api/v3/coins/${id}?tickers=false&market_data=true&community_data=false&developer_data=false&sparkline=false`)
  }

  currency_supported(){
    return this.http.get(`https://api.coingecko.com/api/v3/simple/supported_vs_currencies`)
  }

  search_coin(search:string){
    return this.http.get(`https://api.coingecko.com/api/v3/search?query=${search}`)
  }

  trending_coin(){
    return this.http.get(`https://api.coingecko.com/api/v3/search/trending`)
  }

  crypto_list(limit:number,page:number,curr:string){
    return this.http.get(`https://api.coingecko.com/api/v3/coins/markets?vs_currency=${curr}&order=market_cap_desc&per_page=${limit}&page=${page}&sparkline=true&price_change_percentage=1h%2C24h%2C7d&locale=en`)
  }
  coin_market(id:string,day:string){
    return this.http.get(`https://api.coingecko.com/api/v3/coins/${id}/market_chart?vs_currency=inr&days=${day}&precision=2`)
  }
  coin_ohlc_data(id:string,day:string){
    return this.http.get(`https://api.coingecko.com/api/v3/coins/${id}/ohlc?vs_currency=inr&days=${day}&precision=2`)
  }

  snackMessage(message:string){
    this._snackBar.open(message,'',{
      panelClass:['limitPlayers'],
      horizontalPosition:'center',
      verticalPosition:'bottom',
      duration:3000,
    })
  }

  global_crypto(){
    return this.http.get(`https://api.coingecko.com/api/v3/global`)
  }

}
