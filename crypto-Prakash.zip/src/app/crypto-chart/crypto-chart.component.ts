import { Component,OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CryptoApiService } from '../service/crypto-api.service';
import * as Highcharts from 'highcharts';
import HStockTools from "highcharts/modules/stock-tools";
import HC_stock from 'highcharts/modules/stock';
import { LoaderComponent } from '../loader/loader.component';
import { MatDialog } from '@angular/material/dialog';

HC_stock(Highcharts);
HStockTools(Highcharts);

@Component({
  selector: 'app-crypto-chart',
  templateUrl: './crypto-chart.component.html',
  styleUrls: ['./crypto-chart.component.scss']
})
export class CryptoChartComponent implements OnInit {

  crypto_id: any;
  coin_data: any={};
  coin_description=''

  crypto_data:any[]=[]
  ohlc_data: any=[]
  unit=false
  day:string='max'
  Highcharts: typeof Highcharts = Highcharts;



  constructor(private activeRouter:ActivatedRoute,public router:Router,private _cryptoApi:CryptoApiService,private dialog:MatDialog) {}

  ngOnInit(){
    this.dialog.open(LoaderComponent)

  this.unit=JSON.parse(localStorage.getItem('tempUnit')||'false')

  this.crypto_id= this.activeRouter.snapshot.paramMap.get('id')  

  this.coin_details()
  
  this.get_coin_data()
  
  }
  
  get_coin_data(){
    
  
    this._cryptoApi.coin_market(this.crypto_id,this.day).subscribe({
      next:(res:any)=>
      {
        this.crypto_data=res.total_volumes

        // console.log(res.prices);
      },
      error:(err)=>
      {
        this.dialog.closeAll();
        this._cryptoApi.snackMessage('Api Call Limit !!!')
       },
      complete:()=>
      {
        this._cryptoApi.coin_ohlc_data(this.crypto_id,this.day).subscribe({

          next:(res:any)=>
          {
            this.ohlc_data=res
          },
          error:(err)=>{
            this.dialog.closeAll();
            this._cryptoApi.snackMessage('Api Call Limit !!!')
           },
          complete:()=>
          {
                 this.chartGui('ohlc')
                 this.dialog.closeAll();
          }
        })
      }
    })
  }

 chartGui(typ:string) {

  let chart = Highcharts.stockChart('container', {
    credits: {
      enabled: false
    },
      yAxis: [{
          labels: {
              align: 'left'
          },
          height: '80%',
          resize: {
              enabled: true
          }
      }, {
          labels: {
              align: 'left'
          },
          top: '80%',
          height: '20%',
          offset: 0
      }],
      tooltip: {
          shape: 'square',
          headerShape: 'callout',
          borderWidth: 0,
          shadow: false,
          
          positioner: function (width: number, height: any, point:any) {
            let position;

                position = {
                    x: Math.max(
                        // Left side limit
                        chart.plotLeft,
                        Math.min(
                            point.plotX + chart.plotLeft - width / 2,
                            // Right side limit
                        )
                    ),
                    y: point.plotY
                };
            return position;
        }
      },
      series: [
      {
          type: 'column',
          id: `${this.crypto_id}-volume`,
          name: `${this.crypto_id} Volume`,
          data: this.crypto_data,
          yAxis: 1
      },
      {
        name: `${this.crypto_id}`,
        // type: 'area',
        type:typ,
        data: this.ohlc_data,
        gapSize: 5,
        tooltip: {
            valueDecimals: 2
        },
        color: '#2e71ff',
        fillColor: {
          linearGradient: { x1: 0, x2: 0, y1: 0.1, y2: 1 },
          stops: [
              [0, '#25a7da'],
              [1,Highcharts.color('#d3edf8').setOpacity(0.25).get()]
          ]
      },
        threshold: null
    }
      
    ],
      responsive: {
          rules: [{
              condition: {
                  maxWidth: 800
              },
              chartOptions: {
                  rangeSelector: {
                      inputEnabled: false
                  }
              }
          }]
      }
  }as any);
  // console.log(ohlc);
};

change_degree(event:any){
  console.log(event.target.checked);
  localStorage.setItem('tempUnit',event.target.checked)

  this.unit=JSON.parse(localStorage.getItem('tempUnit')||'false')
 }

getData(para:any){
  console.log(para.value);
  this.chartGui(para.value)
  // this.day=para.value
  // this.get_coin_data()
}

coin_details(){
  this._cryptoApi.coin_info(this.crypto_id).subscribe({
    next:(res:any)=>{
      console.log(res);
      this.coin_data=res
      this.coin_description=res.description.en

    },
    error:(err)=>{
      console.log(err);
    },
    complete:()=>{
      // this.dialog.closeAll()
    }
  })
}

}

